
const form = document.createElement("form");
form.innerHTML = `
  <textarea id="anfrage" rows="6" cols="50" placeholder="Kundenanfrage eingeben..."></textarea><br>
  <button type="submit">Antwort generieren</button>
  <pre id="antwort"></pre>
`;
document.getElementById("root").appendChild(form);

form.addEventListener("submit", function(e) {
    e.preventDefault();
    const text = document.getElementById("anfrage").value.toLowerCase();
    let antwort = "Vielen Dank für Ihre Nachricht. Wir kümmern uns schnellstmöglich um Ihr Anliegen.\n\n";

    if (text.includes("defekt") || text.includes("beschädigt")) {
        antwort += "Es tut uns sehr leid, dass Sie ein defektes Produkt erhalten haben. Bitte senden Sie uns den Artikel zurück.";
    } else if (text.includes("rechnung")) {
        antwort += "Ihre Rechnung haben wir Ihnen soeben per E-Mail zugesendet.";
    } else if (text.includes("lieferung") || text.includes("versand")) {
        antwort += "Ihre Bestellung wurde versendet. Die Sendungsverfolgung finden Sie in Ihrem Kundenkonto.";
    } else {
        antwort += "Wir kümmern uns um Ihr Anliegen und melden uns zeitnah bei Ihnen.";
    }

    document.getElementById("antwort").textContent = antwort;
});
